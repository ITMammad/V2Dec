const ui = require("./ui")

module.exports = (data) => {
    // var data = [0, 153, 25, 148, 38, 107, 71, 65, 253, 131, 149, 186, 229, 170, 151, 216, 18, 0, 1, 1, 187, 2, 14, 119, 119, 119, 46, 103, 111, 111, 103, 108, 101, 46, 99, 111, 109, 22, 3, 3, 0, 165, 1, 0, 0, 161, 3, 3, 100, 202, 102, 229, 19, 36, 72, 199, 217, 0, 16, 203, 247, 191, 61, 10, 199, 45, 227, 173, 133, 214, 138, 103, 213, 45, 162, 9, 229, 153, 195, 78, 0, 0, 36, 192, 44, 192, 43, 192, 48, 192, 47, 192, 36, 192, 35, 192, 40, 192, 39, 192, 10, 192, 9, 192, 20, 192, 19, 0, 157, 0, 156, 0, 61, 0, 60, 0, 53, 0, 47, 1, 0, 0, 84, 0, 0, 0, 19, 0, 17, 0, 0, 14, 119, 119, 119, 46, 103, 111, 111, 103, 108, 101, 46, 99, 111, 109, 0, 10, 0, 8, 0, 6, 0, 29, 0, 23, 0, 24, 0, 11, 0, 2, 1, 0, 0, 13, 0, 26, 0, 24, 8, 4, 8, 5, 8, 6, 4, 1, 5, 1, 2, 1, 4, 3, 5, 3, 2, 3, 2, 2, 6, 1, 6, 3, 0, 35, 0, 0, 0, 23, 0, 0, 255, 1, 0, 1, 0];

    // 0th Byte
    const version = data[0];
    // 1st Byte
    var uuidBytesarray = [];
    for (let i = 1; i < 17; i++) {
        const element = data[i];
        uuidBytesarray.push(Buffer.from([element]).toString("hex"))
    }
    var uuidWithoutDelimiter = uuidBytesarray.join("");
    var uuid1 = uuidWithoutDelimiter.substr(0, 8);
    var uuid2 = uuidWithoutDelimiter.substr(8, 4);
    var uuid3 = uuidWithoutDelimiter.substr(12, 4);
    var uuid4 = uuidWithoutDelimiter.substr(16, 4);
    var uuid6 = uuidWithoutDelimiter.substr(20, 12);
    const uuid = [uuid1, uuid2, uuid3, uuid4, uuid6].join("-");
    // 17th Byte
    var AIPL /* Additional Information ProtoBuf Length */ = data[17];
    var AIP = [];
    for (let i = 17; i <= AIPL; i++) {
        const element = data[i];
        AIP.push(element)
    }
    // (18 + AIPL)th
    var index = 18 + AIPL;
    var instruction = data[index];
    // (19 + AIPL)th
    var index = 19 + AIPL;
    var port = [data[index], data[index + 1]].join("");
    // (21 + AIPL)th
    var index = 21 + AIPL;
    var addressType = data[index];
    // (22 + AIPL)th
    var index = 22 + AIPL;
    var addressLength = data[index];
    // (23 + AIPL)th
    var index = 23 + AIPL;
    var addressBytesArray = [];
    for (let i = index; i < index + addressLength; i++) {
        const element = data[i];
        addressBytesArray.push(element)
    }
    var address = Buffer.from(addressBytesArray).toString("ascii");
    // (24 + AIPL + AddressLength)th
    var index = 24 + AIPL + addressLength;
    var requestDataBytesArray = [];
    for (let i = index; i < data.length; i++) {
        const element = data[i];
        requestDataBytesArray.push(element);
    }

    // Processing Request
    // if (ui.checkUUID(uuid) === true && ui.checkAddress(address) === true && Buffer.from([requestDataBytesArray[0]]).toString("ascii").match(/[a-z]/i)) {
    var responseData = "";
    if (ui.checkUUID(uuid) === true && ui.checkAddress(address) === true) {
        responseData = `HTTP/1.1 200 OK
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate, br
Accept-Language: en-US,en;q=0.9,fa-IR;q=0.8,fa;q=0.7,en-VI;q=0.6,en-AU;q=0.5,en-CA;q=0.4
Cookie: SID=YgisOWVDSbYLp-iIOsZ4gIGqCwQy9BaZqfGAFcB-nXDxkhihBZKwwFwRur9PUNrt2Z3u9w.; __Secure-1PSID=YgisOWVDSbYLp-iIOsZ4gIGqCwQy9BaZqfGAFcB-nXDxkhihHHksx36SHBL7SIx8tuIhHA.; __Secure-3PSID=YgisOWVDSbYLp-iIOsZ4gIGqCwQy9BaZqfGAFcB-nXDxkhihU3hp146LoN-R7JlRx6Q30Q.; HSID=Aw69mCzpm9iYGQ7Hd; SSID=A3RWmwJ1y9sEMdjIp; APISID=VTO4AQqtnamgBC-9/AWCdyFVFm6437lvwJ; SAPISID=95aNXXnnrBvp1HPm/AQUATLLFi85jc_flQ; __Secure-1PAPISID=95aNXXnnrBvp1HPm/AQUATLLFi85jc_flQ; __Secure-3PAPISID=95aNXXnnrBvp1HPm/AQUATLLFi85jc_flQ; OTZ=7114095_42_42_114990_38_379890; SEARCH_SAMESITE=CgQI75gB; AEC=Ad49MVFbwca5aR6MLUfU1RRpzrGH61qzVoz5Gzpwpa7QdPeN8Ql2M1oKwA; __Secure-1PSIDTS=sidts-CjIBPu3jIRUe639wApxkODivX9TO7V2lq_A-ErM9Z-BMYCJT2dcvktpnBJXtaxQVtv9PNxAA; __Secure-3PSIDTS=sidts-CjIBPu3jIRUe639wApxkODivX9TO7V2lq_A-ErM9Z-BMYCJT2dcvktpnBJXtaxQVtv9PNxAA; NID=511=Ybrnum08PRj3gEEcmUwiz8EKDXLD20lwJxYyWuGpQUO-pTN4qtkQu13KEjzfD6PNMIIUEyclCVRVWybIsHM8KKt1OBcTToaHEv1qJX5ZzEfrqhWMDIz4lpbDM262BJQscwS1jbHF3oDpNW8u7xYXcIx5vFrcfoFiCERoOs8BNxCwaInqLJLvMG29Vso8RFy4a4p30EZJLkBJRXf2TdbiGTf4WGyMmcr7knBvc7c5GXmMiEuBhi7lcFAciYxHL8gfNazo2VxrDJG6r_RKPQMW-abolJ2pq8aNMBvGRl0fbacl10y8-8mEJJD2uPn-W3FYn_miNzaisQQ6Ck4rh8D7rP-XJXTeVBlqgubgKjU1GmaQ2pfL86vZOp9j2rSnIQ; __Secure-ENID=13.SE=p15tcyb7gDwPJhFWJrAswtzluC-farBd6LaBj3cQjSt5U63JqqgNnET5HYbDlPiicXFEoAn2E6awrJ1ke7TA2S2CElAM03gCaW9WNXuVXqCE3Qj2sciT7R9a3ItoeWvdjTROXAkPYcXe41FoDq51ps45Ks9jWEyq9Ka5FzlQL1qccdroaOtjq9e-6U5espC9cyjJfBm8mP4cZZgmyFIPVHZWcc0-EAa6xuL_PVTIJVdD2biNm2cmpDWIGK1j80Ld4lTkWCYh8GXw4E4wdiZUy8SaA10h--oeHzCMYLDHp8qTEqA2CEJpVEDPMz0yNA; DV=c-0wBiyS_F9cwOHOSNGMdZAlsyixm5hw4P5MyRCtgwEAAAAifm2YC1-ebQAAAKxvDnFuwjx5LQAAAGggPL0IFLG4DgAAAA; 1P_JAR=2023-8-3-11; SIDCC=APoG2W-xxhbf2eIsthifi27pXvFYgy1HvVyZSyWXoARNAB7DFw-Jjwy8YhmjT_RN9wswfCmfzQ; __Secure-1PSIDCC=APoG2W_NLuPn2L4jqOZL0mRrL1Qe2be4lQ1Dtg2Z2-4wvxkR6eNopzci_7GEobDgRUsEm-J-LA; __Secure-3PSIDCC=APoG2W-1hguBXg9OeCfHCCHkW36MNlS3p0WsQeoCSfNLSxOz_jTywB9AndysqyWvhLlDnxskm54
Dnt: 1
Sec-Ch-Ua: "Not/A)Brand";v="99", "Google Chrome";v="115", "Chromium";v="115"
Sec-Ch-Ua-Arch: "x86"
Sec-Ch-Ua-Bitness: "64"
Sec-Ch-Ua-Full-Version: "115.0.5790.110"
Sec-Ch-Ua-Full-Version-List: "Not/A)Brand";v="99.0.0.0", "Google Chrome";v="115.0.5790.110", "Chromium";v="115.0.5790.110"
Sec-Ch-Ua-Mobile: ?0
Sec-Ch-Ua-Model: ""
Sec-Ch-Ua-Platform: "Windows"
Sec-Ch-Ua-Platform-Version: "15.0.0"
Sec-Ch-Ua-Wow64: ?0
Sec-Fetch-Dest: document
Sec-Fetch-Mode: navigate
Sec-Fetch-Site: none
Sec-Fetch-User: ?1
Upgrade-Insecure-Requests: 1
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36
X-Client-Data: CJW2yQEIorbJAQipncoBCI7jygEIlKHLAQiFk80BCIWgzQEIi6fNAQiXss0BCNq0zQEIo73NAQjevc0BCLy+zQEI38TNAQjuxM0BCKnFzQEIwcXNAQj1xc0B

<!DOCTYPE html>
<html lang=en>
  <meta charset=utf-8>
  <meta name=viewport content="initial-scale=1, minimum-scale=1, width=device-width">
  <title>Error 403 (Forbidden)!!1</title>
  <style>
    *{margin:0;padding:0}html,code{font:15px/22px arial,sans-serif}html{background:#fff;color:#222;padding:15px}body{margin:7% auto 0;max-width:390px;min-height:180px;padding:30px 0 15px}* > body{background:url(//www.google.com/images/errors/robot.png) 100% 5px no-repeat;padding-right:205px}p{margin:11px 0 22px;overflow:hidden}ins{color:#777;text-decoration:none}a img{border:0}@media screen and (max-width:772px){body{background:none;margin-top:0;max-width:none;padding-right:0}}#logo{background:url(//www.google.com/images/branding/googlelogo/1x/googlelogo_color_150x54dp.png) no-repeat;margin-left:-5px}@media only screen and (min-resolution:192dpi){#logo{background:url(//www.google.com/images/branding/googlelogo/2x/googlelogo_color_150x54dp.png) no-repeat 0% 0%/100% 100%;-moz-border-image:url(//www.google.com/images/branding/googlelogo/2x/googlelogo_color_150x54dp.png) 0}}@media only screen and (-webkit-min-device-pixel-ratio:2){#logo{background:url(//www.google.com/images/branding/googlelogo/2x/googlelogo_color_150x54dp.png) no-repeat;-webkit-background-size:100% 100%}}#logo{display:inline-block;height:54px;width:150px}
  </style>
  <a href=//www.google.com/><span id=logo aria-label=Google></span></a>
  <p><b>403.</b> <ins>That's an error.</ins>
  <p>Your client does not have permission to get URL <code>/</code> from this server.  <ins>That's all we know.</ins>`;
        console.log(`
        1. Protocol Version: ${version}
        2. UUID: ${uuid}
        3. Address: ${address}
        4. Data: ${Buffer.from(requestDataBytesArray).toString("ascii")}`);
    } else {
        responseData = requestDataBytesArray;
    }

    // Prepairing Response
    var response = [Buffer.from([version]), Buffer.from([AIPL])];

    if (AIPL !== 0) {
        response.push(Buffer.from([AIP]))
    }

    response.push(Buffer.from(responseData));

    return Buffer.concat(response);
}